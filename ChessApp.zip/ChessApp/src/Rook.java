import java.awt.Image;
import javax.swing.ImageIcon;

public class Rook extends Piece {
	public Rook(boolean isWhite) {
		super(PieceType.ROOK, isWhite);
	}

	@Override
	public boolean isValidMove(int startX, int startY, int endX, int endY, Piece[][] board) {
		if (startX == endX || startY == endY) {
			int dx = Math.abs(startX - endX);
			int dy = Math.abs(startY - endY);
			int xDirection = (endX - startX) / (dx == 0 ? 1 : dx);
			int yDirection = (endY - startY) / (dy == 0 ? 1 : dy);
			for (int i = 1; i < Math.max(dx, dy); i++) {
				if (board[startX + i * xDirection][startY + i * yDirection] != null) {
					return false;
				}
			}
			return board[endX][endY] == null || board[endX][endY].isWhite() != isWhite();
		}
		return false;
	}

	@Override
	public Image getImage() {
		String filename = isWhite() ? "assets/Chess Pieces/White/WhiteRook.png" : "assets/Chess Pieces/Black/BlackRook.png";
		return new ImageIcon(filename).getImage();
	}
}