import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ChessBoard extends JPanel {
	private Piece[][] board;
	private Piece selectedPiece;
	private int selectedX, selectedY;
	private boolean whiteTurn = true;
	private boolean gameEnded = false; // New flag to indicate game end

	private final int SQUARE_SIZE = 50;
	private final int BOARD_SIZE = 8 * SQUARE_SIZE;

	private final int NUMBERS_WIDTH = 20;
	private final int LETTERS_HEIGHT = 20;

	private final Piece[][] startingPosition = {
			{new Rook(false), new Knight(false), new Bishop(false), new Queen(false), new King(false), new Bishop(false), new Knight(false), new Rook(false)},
			{new Pawn(false), new Pawn(false), new Pawn(false), new Pawn(false), new Pawn(false), new Pawn(false), new Pawn(false), new Pawn(false)},
			{null, null, null, null, null, null, null, null},
			{null, null, null, null, null, null, null, null},
			{null, null, null, null, null, null, null, null},
			{null, null, null, null, null, null, null, null},
			{new Pawn(true), new Pawn(true), new Pawn(true), new Pawn(true), new Pawn(true), new Pawn(true), new Pawn(true), new Pawn(true)},
			{new Rook(true), new Knight(true), new Bishop(true), new Queen(true), new King(true), new Bishop(true), new Knight(true), new Rook(true)}
	};

	private JTextArea movementNotation;
	private JFrame frame;

	public ChessBoard() {
		this.board = new Piece[8][8];
		resetBoard();
		addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if (!gameEnded) { // Only handle clicks if the game has not ended
					int x = (e.getX() - NUMBERS_WIDTH) / SQUARE_SIZE;
					int y = (e.getY() - LETTERS_HEIGHT) / SQUARE_SIZE;
					handleMouseClick(x, y);
				}
			}
		});
	}

	public void setMovementNotation(JTextArea movementNotation) {
		this.movementNotation = movementNotation;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

	public void startGame() {
		// Remove initial message
	}

	public void resetBoard() {
		for (int row = 0; row < 8; row++) {
			System.arraycopy(startingPosition[row], 0, board[row], 0, 8);
		}
		whiteTurn = true;
		selectedPiece = null;
		gameEnded = false; // Reset game end flag
		repaint();
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.setColor(Color.BLACK);
		g.fillRect(NUMBERS_WIDTH, LETTERS_HEIGHT, BOARD_SIZE, BOARD_SIZE);

		for (int row = 0; row < 8; row++) {
			for (int col = 0; col < 8; col++) {
				drawSquare(g, row, col);
				if (board[row][col] != null) {
					g.drawImage(board[row][col].getImage(), col * SQUARE_SIZE + NUMBERS_WIDTH,
							row * SQUARE_SIZE + LETTERS_HEIGHT, SQUARE_SIZE, SQUARE_SIZE, null);
				}
			}
		}

		g.setColor(Color.BLACK);
		for (int i = 0; i < 8; i++) {
			char letter = (char) ('A' + i);
			g.drawString(String.valueOf(letter), i * SQUARE_SIZE + NUMBERS_WIDTH + SQUARE_SIZE / 2 - 5,
					LETTERS_HEIGHT - 5);
			g.drawString(String.valueOf(8 - i), NUMBERS_WIDTH - 15,
					i * SQUARE_SIZE + LETTERS_HEIGHT + SQUARE_SIZE / 2 + 5);
		}
		for (int i = 0; i < 8; i++) {
			char letter = (char) ('A' + i);
			g.drawString(String.valueOf(letter), i * SQUARE_SIZE + NUMBERS_WIDTH + SQUARE_SIZE / 2 - 5,
					BOARD_SIZE + LETTERS_HEIGHT + 15);
			g.drawString(String.valueOf(8 - i), NUMBERS_WIDTH + BOARD_SIZE + 10,
					i * SQUARE_SIZE + LETTERS_HEIGHT + SQUARE_SIZE / 2 + 5);
		}

		if (selectedPiece != null) {
			highlightValidMoves(g);
		}
	}

	private void drawSquare(Graphics g, int row, int col) {
		Color color = (row + col) % 2 == 0 ? new Color(240, 217, 181) : new Color(181, 136, 99);
		g.setColor(color);
		g.fillRect(col * SQUARE_SIZE + NUMBERS_WIDTH, row * SQUARE_SIZE + LETTERS_HEIGHT, SQUARE_SIZE, SQUARE_SIZE);
	}

	private void handleMouseClick(int x, int y) {
		if (selectedPiece == null) {
			if (board[y][x] != null && (whiteTurn && board[y][x].isWhite() || !whiteTurn && !board[y][x].isWhite())) {
				selectedPiece = board[y][x];
				selectedX = x;
				selectedY = y;
				repaint();
			}
		} else {
			if (selectedPiece.isValidMove(selectedY, selectedX, y, x, board)) {
				String color = whiteTurn ? "White" : "Black";
				String pieceType = selectedPiece.getClass().getSimpleName();
				String notation = color + " " + pieceType + ": "
						+ convertToChessNotation(selectedY, selectedX) + " - " + convertToChessNotation(y, x);
				updateMovementNotation(notation);

				if (board[y][x] instanceof King) {
					board[y][x] = selectedPiece;
					board[selectedY][selectedX] = null;
					displayEndGameMessage(color);
					gameEnded = true; // End the game
				} else {
					board[y][x] = selectedPiece;
					board[selectedY][selectedX] = null;
					whiteTurn = !whiteTurn;
				}
			}
			selectedPiece = null;
			repaint();
		}
	}

	private void highlightValidMoves(Graphics g) {
		g.setColor(new Color(0, 255, 0, 100));
		int startX = selectedY;
		int startY = selectedX;
		for (int x = 0; x < 8; x++) {
			for (int y = 0; y < 8; y++) {
				if (selectedPiece.isValidMove(startX, startY, x, y, board)) {
					g.fillRect(y * SQUARE_SIZE + NUMBERS_WIDTH, x * SQUARE_SIZE + LETTERS_HEIGHT,
							SQUARE_SIZE, SQUARE_SIZE);
				}
			}
		}
	}

	private void displayEndGameMessage(String color) {
		updateMovementNotation(color + " wins!\n");
	}

	private void updateMovementNotation(String text) {
		if (movementNotation != null) {
			movementNotation.append(text + "\n");
		}
	}

	private String convertToChessNotation(int x, int y) {
		char file = (char) ('A' + y);
		char rank = (char) ('8' - x);
		return "" + file + rank;
	}

	@Override
	public Dimension getPreferredSize() {
		return new Dimension(BOARD_SIZE + NUMBERS_WIDTH + 30, BOARD_SIZE + LETTERS_HEIGHT + 100);
	}
}