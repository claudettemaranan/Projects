import java.awt.Image;
import javax.swing.ImageIcon;

public class Knight extends Piece {
	public Knight(boolean isWhite) {
		super(PieceType.KNIGHT, isWhite);
	}

	@Override
	public boolean isValidMove(int startX, int startY, int endX, int endY, Piece[][] board) {
		int dx = Math.abs(startX - endX);
		int dy = Math.abs(startY - endY);
		if (dx * dy == 2) {
			return board[endX][endY] == null || board[endX][endY].isWhite() != isWhite();
		}
		return false;
	}

	@Override
	public Image getImage() {
		String filename = isWhite() ? "assets/Chess Pieces/White/WhiteKnight.png" : "assets/Chess Pieces/Black/BlackKnight.png";
		return new ImageIcon(filename).getImage();
	}
}