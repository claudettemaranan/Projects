import java.awt.Image;
import javax.swing.ImageIcon;

public class Pawn extends Piece {
	public Pawn(boolean isWhite) {
		super(PieceType.PAWN, isWhite);
	}

	@Override
	public boolean isValidMove(int startX, int startY, int endX, int endY, Piece[][] board) {
		int direction = isWhite() ? -1 : 1;
		if (startX + direction == endX && startY == endY && board[endX][endY] == null) {
			return true;
		}
		if (startX + 2 * direction == endX && startY == endY && board[endX][endY] == null && board[startX + direction][startY] == null && (startX == 1 || startX == 6)) {
			return true;
		}
		if (startX + direction == endX && (startY + 1 == endY || startY - 1 == endY) && board[endX][endY] != null && board[endX][endY].isWhite() != isWhite()) {
			return true;
		}
		return false;
	}

	@Override
	public Image getImage() {
		String filename = isWhite() ? "assets/Chess Pieces/White/WhitePawn.png" : "assets/Chess Pieces/Black/BlackPawn.png";
		return new ImageIcon(filename).getImage();
	}
}