import java.awt.Image;
import javax.swing.ImageIcon;

public class King extends Piece {
	public King(boolean isWhite) {
		super(PieceType.KING, isWhite);
	}

	@Override
	public boolean isValidMove(int startX, int startY, int endX, int endY, Piece[][] board) {
		int dx = Math.abs(startX - endX);
		int dy = Math.abs(startY - endY);
		if (dx <= 1 && dy <= 1) {
			return board[endX][endY] == null || board[endX][endY].isWhite() != isWhite();
		}
		return false;
	}

	@Override
	public Image getImage() {
		String filename = isWhite() ? "assets/Chess Pieces/White/WhiteKing.png" : "assets/Chess Pieces/Black/BlackKing.png";
		return new ImageIcon(filename).getImage();
	}
}