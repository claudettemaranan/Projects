import javax.swing.*;
import java.awt.*;

public class Chess {
	public static void main(String[] args) {
		JFrame frame = new JFrame("Chess Game");
		ChessBoard board = new ChessBoard();
		JPanel bottomPanel = new JPanel(new BorderLayout());

		JTextArea movementNotation = new JTextArea();
		movementNotation.setEditable(false);
		JScrollPane scrollPane = new JScrollPane(movementNotation);
		bottomPanel.add(scrollPane, BorderLayout.CENTER);

		JButton playAgainButton = new JButton("Play Again");
		playAgainButton.addActionListener(e -> {
			board.resetBoard();
			board.startGame();
			movementNotation.setText("");
		});
		bottomPanel.add(playAgainButton, BorderLayout.SOUTH);

		JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, board, bottomPanel);
		splitPane.setDividerLocation(450);

		frame.add(splitPane);
		frame.pack();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

		board.setMovementNotation(movementNotation);
		board.setFrame(frame);
		board.startGame();
	}
}
