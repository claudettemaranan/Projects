import java.awt.Image;
import javax.swing.ImageIcon;

public class Bishop extends Piece {
	public Bishop(boolean isWhite) {
		super(PieceType.BISHOP, isWhite);
	}

	@Override
	public boolean isValidMove(int startX, int startY, int endX, int endY, Piece[][] board) {
		int dx = Math.abs(startX - endX);
		int dy = Math.abs(startY - endY);
		if (dx == dy && dx != 0 && dy != 0) {
			int xDirection = (endX - startX) / dx;
			int yDirection = (endY - startY) / dy;
			for (int i = 1; i < dx; i++) {
				if (board[startX + i * xDirection][startY + i * yDirection] != null) {
					return false;
				}
			}
			return board[endX][endY] == null || board[endX][endY].isWhite() != isWhite();
		}
		return false;
	}

	@Override
	public Image getImage() {
		String filename = isWhite() ? "assets/Chess Pieces/White/WhiteBishop.png" : "assets/Chess Pieces/Black/BlackBishop.png";
		return new ImageIcon(filename).getImage();
	}
}